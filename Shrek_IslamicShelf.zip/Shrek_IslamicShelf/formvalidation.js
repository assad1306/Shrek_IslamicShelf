document.getElementById("checkoutForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const firstName = document.getElementById("firstName").value.trim();
  const lastName = document.getElementById("lastName").value.trim();
  const address = document.getElementById("address").value.trim();

  if (!firstName || !lastName || !address) {
      alert("Please fill in all required fields.");
      return;
  }

  alert("Form submitted successfully!");
});
