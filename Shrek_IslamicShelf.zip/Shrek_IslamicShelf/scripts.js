// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function() {
  // Loader
  setTimeout(() => {
      document.querySelector('.loader-container').classList.add('active');
  }, 2000);

  // Books Slider
  new Swiper(".books-slider", {
      loop: true,
      centeredSlides: true,
      autoplay: {
          delay: 9500,
          disableOnInteraction: false,
      },
      breakpoints: {
          0: { slidesPerView: 1 },
          768: { slidesPerView: 2 },
          1024: { slidesPerView: 3 },
      },
  });

  // Featured Slider
  new Swiper(".featured-slider", {
      spaceBetween: 10,
      loop: true,
      centeredSlides: true,
      autoplay: {
          delay: 9500,
          disableOnInteraction: false,
      },
      breakpoints: {
          0: { slidesPerView: 1 },
          450: { slidesPerView: 2 },
          768: { slidesPerView: 3 },
          1024: { slidesPerView: 4 },
      },
  });

  // Reviews Slider
  new Swiper(".reviews-slider", {
    spaceBetween: 20,
    grabCursor: true,
    loop: true,
    autoplay: {
        delay: 9500,
        disableOnInteraction: false,
    },
    breakpoints: {
        0: { slidesPerView: 1 },
        768: { slidesPerView: 2 },
        1024: { slidesPerView: 3 },
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
});
});