function addToCartAndRedirect() {
    // Add item to cart
    const bookId = new URLSearchParams(window.location.search).get('book');
    // Save to localStorage or your cart management system
    window.location.href = "cart.html";
}