// Remove Items From Cart
$(document).on('click', 'a.remove', function(event) {
  event.preventDefault(); // Prevent the default action of the link
  $(this).closest('.items').fadeOut(400, function() {
    $(this).remove(); // Remove the item from the DOM after fading out
  });
});
