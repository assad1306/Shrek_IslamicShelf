function searchBooks() {
    // Get the search input value
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    // Get all book elements
    const books = document.querySelectorAll('.book');
    
    // Track if we found any matches
    let foundMatch = false;
    
    // Loop through each book
    books.forEach(book => {
        const title = book.querySelector('p').textContent.toLowerCase();
        
        // Check if the book title contains the search term
        if (title.includes(searchTerm)) {
            book.style.display = 'block';
            foundMatch = true;
        } else {
            book.style.display = 'none';
        }
    });
    
    // Show/hide no results message
    const noResults = document.getElementById('noResults');
    if (!foundMatch && searchTerm !== '') {
        if (!noResults) {
            const message = document.createElement('div');
            message.id = 'noResults';
            message.className = 'no-results';
            message.textContent = 'No books found matching your search.';
            document.querySelector('.book-list').before(message);
        }
    } else if (noResults) {
        noResults.remove();
    }
}

// Add real-time search as user types
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', searchBooks);
    }
});

// Clear search when clicking the back button
document.querySelector('.back-btn').addEventListener('click', function() {
    document.getElementById('searchInput').value = '';
    searchBooks();
});
document.addEventListener('DOMContentLoaded', function() {
    // Get the book parameter from URL
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('book');
    
    // You can use this bookId to load the correct book information
    const bookData = {
        'hijrah': {
            title: 'Tuhan Aku Ingin Hijrah',
            image: 'tuhan aku ingin berhijrah.jpg',
            price: 'RM40.00',
            author: 'Author Name',
            description: 'Book description here...'
        },
    };

    // Update the product page with the correct book information
    if (bookData[bookId]) {
        const book = bookData[bookId];
        document.querySelector('.book-details h1').textContent = book.title;
        document.querySelector('.book-image img').src = book.image;
        document.querySelector('.price span').textContent = book.price;
        // Update other elements as needed
    }
});