// auth.js
function checkLoginStatus() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
        window.location.href = 'loginpage.html';
    }
}

function logout() {
    localStorage.removeItem('isLoggedIn');
    window.location.href = 'loginpage.html';
}